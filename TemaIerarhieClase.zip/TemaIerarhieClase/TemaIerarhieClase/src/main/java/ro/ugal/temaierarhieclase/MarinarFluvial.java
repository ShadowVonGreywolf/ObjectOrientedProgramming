/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author denia
 */
public class MarinarFluvial extends Marinar {
    String numeVapor;
    String port;

    
    
    public MarinarFluvial(String numeVapor, String port, String nume ) {
        this.numeVapor = numeVapor;
        this.port = port;
        setNume(nume);
    }

    public MarinarFluvial() {
    }

    public String getNumeVapor() {
        return numeVapor;
    }

    public void setNumeVapor(String numeVapor) {
        this.numeVapor = numeVapor;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @Override
    public String toString() {
        return "MarinarFluvial{" + "numeVapor=" + numeVapor + ", port=" + port + ", nume= " + getNume() + '}';
    }
    
    @Override 
    public void lucreaza(){
    System.out.println("Lucreaza la Napa");
    }
    @Override 
    public void setNume(String nume) {
        this.nume = nume;
    }
}

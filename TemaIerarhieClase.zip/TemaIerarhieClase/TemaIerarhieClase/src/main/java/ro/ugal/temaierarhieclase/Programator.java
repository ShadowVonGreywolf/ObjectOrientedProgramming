/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
class Programator implements Angajat{
    protected String nume ;

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    @Override
    public String toString() {
        return "Programator{" + "nume=" + nume + '}';
        
    }
    
    Programator(){
        
    }
    
    Programator( String nume){
    this.nume = nume;
    }

    @Override
    public void lucreaza() {
        System.out.println("Lucreaza la Selir");
    }
}

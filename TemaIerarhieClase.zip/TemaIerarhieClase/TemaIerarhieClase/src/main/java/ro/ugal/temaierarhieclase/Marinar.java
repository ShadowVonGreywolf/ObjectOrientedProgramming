/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author denia
 */
public class Marinar implements Angajat{
    String nume;
    int varsta;

    public Marinar(String nume, int  varsta) {
        this.nume = nume;
        this.varsta = varsta;
    }

    public Marinar() {
    }

    @Override
    public String toString() {
        return "Marinar{" + "nume=" + nume + ", varsta=" + varsta + '}';
    }

    @Override
    public void lucreaza() {
       System.out.println("Lucreaza");
    }
    
    
    
}

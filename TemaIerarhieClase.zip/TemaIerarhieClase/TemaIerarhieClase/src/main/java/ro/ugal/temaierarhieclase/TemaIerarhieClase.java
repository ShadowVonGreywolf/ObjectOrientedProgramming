/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ro.ugal.temaierarhieclase;
import java.util.*;
/**
 *
 * @author di214
 */

public class TemaIerarhieClase {

    public static void main(String[] args) {
        //HashSet
        Set<ProgramatorBackend> listaProgramatori = new HashSet<>();
        listaProgramatori.add(new ProgramatorBackend("Java","Junior","John"));
        listaProgramatori.add(new ProgramatorBackend("","","John"));
        listaProgramatori.add(new ProgramatorBackend("Java","Junior","John"));
        System.out.println("Lista programatori Backend de tip HashSet" + listaProgramatori);
        System.out.println("Marimea listei hashset programatori backend = " + listaProgramatori.size());
        System.out.println("Afirmatia : Lista de programatori backend nu contine elemente este " + listaProgramatori.isEmpty());
                
                
        //ArrayList
        ArrayList<MarinarFluvial> listaMarinarFluvial = new ArrayList<>();
        listaMarinarFluvial.add(new MarinarFluvial("HMS Conqueror" , "Constanta","Albert"));
        listaMarinarFluvial.add(new MarinarFluvial("Bismarck" , "Hamburg","Hans"));
        listaMarinarFluvial.add(new MarinarFluvial("USS Dreadnaught" , "New York","Sam"));
        System.out.println("Lista marinari fluviali de tip ArrayList" + listaMarinarFluvial);
        System.out.println("Marinarul pe pozitia 1 = " + listaMarinarFluvial.get(1));
        listaMarinarFluvial.remove(2);
        System.out.println(listaMarinarFluvial);
        
        
        
        
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
interface Angajat{
   void lucreaza();
}

public class TemaIerarhieClase {

    public static void main(String[] args) {
        Programator developer = new Programator("Andrew");
        System.out.println(developer);
        developer.lucreaza();
        ProgramatorBackend programer = new ProgramatorBackend("Senior","Java");
        System.out.println(programer);
        System.out.println( "Limbajul de programare a programatorului backend " + programer.getLanguage());
      
        MarinarMaritim sailor = new MarinarMaritim("HMS Conqueror", 50000);
        System.out.println(sailor);
        String nume = " Gigi";
        sailor.setNume(nume);
        sailor.setVarsta(34);
        System.out.println("nume = " + sailor.getNume() + " ;   varsta = " + sailor.getVarsta());
      
    }
}

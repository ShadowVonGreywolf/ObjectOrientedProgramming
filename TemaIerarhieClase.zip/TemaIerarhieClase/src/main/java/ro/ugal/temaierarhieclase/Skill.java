/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
public class Skill  {
    String skill ; 
    String limbaj; 
    Skill(){
        
    }
    Skill(String skill,  String limbaj){
        this.skill = skill;
        this.limbaj = limbaj;
    }
    public void setSkill(String skill){
        this.skill = skill;
    }
    
    public void setLimbaj (String limbaj){
        this.limbaj=limbaj;
    }
    public void displaySkill(){
        System.out.println("Talent : " + skill + " ; Limbaj : " + limbaj + " ; " );
    }
}

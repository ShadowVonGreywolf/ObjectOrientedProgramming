/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
public class TemaIerarhieClase {

    public static void main(String[] args) {
        Programator developer = new Programator("Andrew");
        System.out.println(developer);
      
       
      
    }
}

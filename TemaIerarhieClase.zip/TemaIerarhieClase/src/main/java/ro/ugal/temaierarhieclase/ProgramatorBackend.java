/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
public class ProgramatorBackend extends Programator {
    String skill;
    String language;
    
    @Override
    public String toString() {
        return "ProgramatorBackend{" + "skill=" + skill + ", language=" + language + '}';
        
    }
    
    ProgramatorBackend(){
    
    }
    
    ProgramatorBackend(String skill, String language){
        this.skill = skill;
        this.language = language;
    }
    
    
    public void setskill(String skill ){
        this.skill = skill;
    }
    
    public String getSkill(String skill){
        return skill;
    }
    
    public String getLanguage(String language){
        return language;
    }
    
    public void displayAttributes(){
         System.out.println(language + "Talent : " + skill + " ; Limbaj : " + " ; " );
    }
    
    
}

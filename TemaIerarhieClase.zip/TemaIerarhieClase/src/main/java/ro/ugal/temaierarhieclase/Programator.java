/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
class Programator {
    protected String nume ;

    @Override
    public String toString() {
        return "Programator{" + "nume=" + nume + '}';
        
    }
    
    Programator(){
        
    }
    
    Programator( String nume){
    this.nume = nume;
    }
}

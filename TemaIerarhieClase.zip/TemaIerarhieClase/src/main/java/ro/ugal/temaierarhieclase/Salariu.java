/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ro.ugal.temaierarhieclase;

/**
 *
 * @author di214
 */
public class Salariu  {
    int suma; 
    int bonuri;
    
    Salariu(){
    
    }
    Salariu (int suma, int bonuri ){
        this.suma = suma;
        this.bonuri = bonuri ;
    }
    public void displayMoney(){
        System.out.println("Salariu = " + suma + " , bonuri = " + bonuri +  " ; ");
    }
}
